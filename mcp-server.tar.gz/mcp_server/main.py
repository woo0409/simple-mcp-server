"""Simple MCP Server - Entry point with SSE support."""

import os
import platform
import asyncio
from datetime import datetime
from typing import Any
from operator import itemgetter

from fastmcp import FastMCP
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Create MCP Server instance
mcp = FastMCP(
    name=os.getenv("MCP_SERVER_NAME", "simple-mcp-server"),
    host=os.getenv("MCP_SERVER_HOST", "0.0.0.0"),
    port=int(os.getenv("MCP_SERVER_PORT", 8000)),
)


# ============= MCP Tools =============

@mcp.tool()
def get_current_time(format: str = "%Y-%m-%d %H:%M:%S") -> str:
    """获取当前服务器时间

    Args:
        format: 时间格式字符串，默认为 "%Y-%m-%d %H:%M:%S"

    Returns:
        格式化的当前时间字符串
    """
    return datetime.now().strftime(format)


@mcp.tool()
def calculate(operation: str, a: float, b: float) -> float:
    """执行简单的数学计算

    Args:
        operation: 运算类型，支持 "add", "subtract", "multiply", "divide"
        a: 第一个数字
        b: 第二个数字

    Returns:
        计算结果

    Raises:
        ValueError: 当运算类型不支持或除数为零时
    """
    operations = {
        "add": lambda x, y: x + y,
        "subtract": lambda x, y: x - y,
        "multiply": lambda x, y: x * y,
        "divide": lambda x, y: x / y if y != 0 else (_ for _ in ()).throw(ValueError("除数不能为零"))
    }

    if operation not in operations:
        raise ValueError(f"不支持的运算类型: {operation}。支持的类型: {', '.join(operations.keys())}")

    return operations[operation](a, b)


@mcp.tool()
def echo(message: str, repeat: int = 1) -> str:
    """回显输入内容

    Args:
        message: 要回显的消息
        repeat: 重复次数，默认为 1

    Returns:
        回显的消息内容
    """
    if repeat < 1:
        raise ValueError("重复次数必须大于等于 1")

    return " ".join([message] * repeat)


@mcp.tool()
def get_server_info() -> dict[str, Any]:
    """获取服务器基本信息

    Returns:
        包含服务器系统信息的字典
    """
    return {
        "hostname": platform.node(),
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "python_version": platform.python_version(),
        "server_time": datetime.now().isoformat()
    }


@mcp.tool()
def reverse_text(text: str) -> str:
    """反转输入的文本

    Args:
        text: 要反转的文本

    Returns:
        反转后的文本
    """
    return text[::-1]


# ============= Resources =============

@mcp.resource("server://status")
def get_server_status() -> str:
    """服务器状态资源"""
    return f"""
    服务器状态 - {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    状态: 运行中
    系统: {platform.system()} {platform.release()}
    """


@mcp.resource("server://tools")
def list_available_tools() -> str:
    """可用工具列表资源"""
    return """
    可用工具列表:
    - get_current_time: 获取当前服务器时间
    - calculate: 执行数学计算 (add, subtract, multiply, divide)
    - echo: 回显输入内容
    - get_server_info: 获取服务器信息
    - reverse_text: 反转文本
    """


# ============= Main Entry Point =============

def main():
    """启动 MCP Server"""
    import uvicorn

    host = os.getenv("MCP_SERVER_HOST", "0.0.0.0")
    port = int(os.getenv("MCP_SERVER_PORT", 8000"))
    log_level = os.getenv("LOG_LEVEL", "info").lower()

    print(f"""
    ╔═══════════════════════════════════════════════════════════╗
    ║           Simple MCP Server - SSE Mode                   ║
    ╠═══════════════════════════════════════════════════════════╣
    ║  Name: {mcp.name:<50} ║
    ║  Host: {host}:{:<46} ║
    ║  SSE Endpoint: http://{host}:{port}/sse              ║
    ║  Message Endpoint: http://{host}:{port}/messages/     ║
    ╚═══════════════════════════════════════════════════════════╝
    """)

    uvicorn.run(
        mcp.app,
        host=host,
        port=port,
        log_level=log_level,
    )


if __name__ == "__main__":
    main()
